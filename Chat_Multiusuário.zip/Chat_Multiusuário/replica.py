"""
Servidor réplica do chat, responsável por receber mensagens de outros servidores e retransmiti-las 
para os clientes conectados. Este servidor é uma réplica do servidor principal e é usado para 
garantir a disponibilidade e a tolerância a falhas do sistema de chat. 
Ele recebe mensagens de outros servidores e as armazena em um arquivo de histórico, além de 
retransmiti-las para os clientes conectados.
"""

from flask import Flask, request
import os

app = Flask(__name__)

arq_hist = "historico de replica.txt"

@app.route('/')
def home():
    return "Servidor réplica do chat está rodando. "

@app.route('/replica', methods=['POST'])
def replicar():
    arq = request.json
    men = arq.get("message")
    with open(arq_hist, "a", encoding="utf-8") as f:
        f.write(f"{men}\n")
    return {
        "status": "ok"
    }
    
if __name__ == '__main__':
    if not os.path.exists(arq_hist):
        with open(arq_hist, "w", encoding="utf-8") as f:
            f.write("")
    app.run(
        host='0.0.0.0', 
        port=5001
        )