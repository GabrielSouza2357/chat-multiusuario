"""
Servidor principal do chat, responsável por gerenciar as conexões dos clientes e a troca de mensagens. 
Ele mantém uma lista de mensagens e usuários conectados, e é responsável 
por enviar mensagens para os clientes e para os servidores réplicas.
"""

from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
from datetime import datetime
import os, requests, threading

# Função para salvar histórico de mensagens em um arquivo:
def salvar_historico(mensagem):
    os.makedirs("historico", exist_ok=True)
    with open(arq_hist, "a", encoding="utf-8") as f:
        f.write(f"{mensagem}\n")

# Função para thread de replicação de mensagens para o servidor réplica:
def replicar_mensagem(mensagem):
    try:
        requests.post(url_rep, json={"message": mensagem}, timeout=3)
    except Exception as e:
        print(f"Erro ao replicar mensagem: {e}")

app = Flask(__name__)
app.config['SECRET_KEY'] = '#Secret!'
socketio = SocketIO(app, cors_allowed_origins="*")

# Lista de mensagens enviadas e usuários conectados:
mensagens = []
usuarios = {}

# Histórico de mensagens:
arq_hist = "historico/mensagens.txt"

# URL do servidor réplica:
url_rep = "https://replica.onrender.com/replica"

@app.route('/')
def index():
    return render_template("index.html")

# Conexão de clientes:
@socketio.on('connect')
def conectar():
    print("\nCliente conectado.")

# Desconexão de clientes:
@socketio.on('disconnect')
def desconectar():
    nome_usuario = usuarios.get(request.sid, "Usuário")
    emit('message', {
        'user': "Servidor", 
        'msg': f"{nome_usuario} saiu do chat."}, 
        broadcast=True)
    usuarios.pop(request.sid, None)
    print("\nCliente desconectado.")
    
# Entrada do usuário
@socketio.on('join')
def entrar(data):
    nome_usuario = data['username']
    usuarios[request.sid] = nome_usuario
    emit('message', {
        'user': "Servidor", 
        'msg': f"{nome_usuario} entrou no chat."
        }, broadcast=True)
    print(f"\n{nome_usuario} entrou no chat.")
    
# Mensagem enviada pelo usuário
@socketio.on('send_message')
def enviar_mensagem(data):
    mensagem = data['msg']
    nome_usuario = usuarios.get(request.sid, "Usuário")
    tempo = datetime.now().strftime('%H:%M:%S')
    men_form = f"[{tempo}] -> {nome_usuario}: {mensagem}"
    
    # Salvar histórico de mensagens
    salvar_historico(men_form)
    
    # Adicionar mensagem à lista
    mensagens.append({'user': nome_usuario, 'msg': mensagem})
    
    # Replicar mensagem para o servidor réplica
    threading.Thread(target=replicar_mensagem, args=(men_form,)).start()
    
    # Enviar mensagem para todos os clientes
    emit('message', {
        'user': nome_usuario, 
        'msg': mensagem, 
        'time': tempo
        }, broadcast=True)
    
    print(f"\n{nome_usuario}: {mensagem}")
    
if __name__ == "__main__":
    if not os.path.exists(arq_hist):
        with open(arq_hist, "w", encoding="utf-8") as f:
            f.write("")
    socketio.run(
        app, 
        host="0.0.0.0", 
        port=5001
        )