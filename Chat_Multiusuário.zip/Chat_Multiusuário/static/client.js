const socket = io();

let nome_usuario = "";

// Cliente recebendo uma thread
socket.on("message", (data) => {
    const pacoteChat = document.getElementById("pacote-chat");
    const div = document.createElement("div");
    div.classList.add("mensagem");
    div.innerHTML = `<strong>${data.user}</strong>${data.time ? `[${data.time}]` : ""} : ${data.msg}`;
    pacoteChat.appendChild(div);
    pacoteChat.scrollTop = pacoteChat.scrollHeight;
});

function entrarNoChat() {
    const nomeInput = document.getElementById("nome-usuario");
    nome_usuario = nomeInput.value.trim();
    if (nome_usuario === "") {
        alert("Por favor, insira um nome de usuário.");
        return;
    }
    socket.emit("join", {
        username: nome_usuario
    });
}

function enviarMensagem() {
    const mensagemInput = document.getElementById("mensagem");
    const mensagem = mensagemInput.value.trim();
    if (mensagem === "") {
        return;
    }
    socket.emit("send_message", { 
        msg: mensagem });
    mensagemInput.value = "";
}